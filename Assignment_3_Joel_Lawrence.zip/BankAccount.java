import java.util.*;

public class BankAccount {
    String accountHolderName;
    String accountNumber;
    double balance;

    Transaction[] transactionList = new Transaction[20];

    Scanner input = new Scanner(System.in);

    Date date = new Date();

    public BankAccount(String name, String accNumber, double bal) {
        accountHolderName = "Unknown";
        accountNumber = "000000";
        balance = 0.0;
    }

    public BankAccount(String name, String accNumber) {
        balance = 0.0;
    }

    public BankAccount(String name, String accNumber, int initialBalance) {
    }

    public void logTransaction(Transaction transaction) {
        for (int i = 0; i < 21; i++) {
            if (transactionList[i] != null) {
                transactionList[i] = transaction;
            }
        }
    }

    public void deposit(double amount) {
        this.balance = this.balance + amount;
    }

    public void deposit(String description, double amount) {
        this.balance = this.balance + amount;
        Transaction transaction1 = new Transaction("Deposit", this.balance, description, date);
        System.out.println("Description : " + description);
    }

    public void withdraw(double amount) {
        if (amount > this.balance) {
            amount = 0;
        } else {
            this.balance = this.balance - amount;
        }

        Transaction transaction1 = new Transaction("Withdraw", this.balance, this.accountNumber, date);
    }

    public void withdraw(String description, double amount) {
        if (amount > this.balance) {
            System.out.println("Not enough funds");
        } else {
            this.balance = this.balance - amount;
            Transaction transaction1 = new Transaction("Withdraw", this.balance, description, date);
            System.out.println("Description: " + description);
        }
    }

    public void displayAccountDetails() {
        System.out.println("Account Holder's Name: " + this.accountHolderName);
        System.out.println("Account Number: " + this.accountNumber);
        System.out.println("Account Balance: " + this.balance);
    }

    public void displayTransactionHistory() {
        System.out.print("Enter account number: ");
        String accNum = input.nextLine();

        for (int i = 0; i < 21; i++) {
            if (accNum.equals(transactionList[i].description)) {
                System.out.println(transactionList[i]);
            }
        }
    }

}